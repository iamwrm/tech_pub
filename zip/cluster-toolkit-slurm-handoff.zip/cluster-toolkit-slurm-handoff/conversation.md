# Visible Conversation Transcript

Exported on **2026-07-28**. This transcript contains the visible user/assistant content in this thread, normalized to Markdown. It excludes private reasoning and hidden system material.

---

## User

Review how https://github.com/GoogleCloudPlatform/cluster-toolkit works to start VM on-demand as slurm compute node under the hood. and if the slurm compute node supports spot

## Assistant

## Conclusion

**Yes—Cluster Toolkit’s Slurm v6 compute nodes support Google Cloud Spot VMs.** Set `enable_spot_vm: true` on the `schedmd-slurm-gcp-v6-nodeset` module. The nodeset can remain fully autoscaling by setting `node_count_static: 0` and an appropriate `node_count_dynamic_max`. Internally, the instance template changes from the `STANDARD` provisioning model to `SPOT`. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/compute/schedmd-slurm-gcp-v6-nodeset/README.md))

There are two different meanings of “on demand” here:

| Dimension | Configuration |
|---|---|
| Create nodes only when Slurm needs them | `node_count_dynamic_max > 0`, usually with `node_count_static: 0` |
| Google Cloud purchasing/provisioning model | `enable_spot_vm: false` gives Standard VMs; `true` gives Spot VMs |

So you can have **autoscaling Standard nodes** or **autoscaling Spot nodes** using essentially the same Slurm lifecycle.

## What happens under the hood

The runtime call chain is:

```text
Job becomes schedulable
        │
        ▼
slurmctld selects logical State=CLOUD node names
        │
        ▼
ResumeProgram = resume_wrapper.sh
        │
        ▼
resume.py
        │
        ├─ reads SLURM_RESUME_FILE
        ├─ groups nodes by nodeset / job / placement policy
        └─ calls Compute Engine Bulk Insert
              ├─ instances.bulkInsert          (single zone)
              └─ regionInstances.bulkInsert    (multiple zones)
        │
        ▼
Fresh GCE VMs boot from the nodeset instance template
        │
        ├─ startup script downloads Slurm configuration/scripts from GCS
        ├─ setup.py mounts storage and runs custom setup
        └─ slurmd starts with configless --conf-server
        │
        ▼
slurmd registers with slurmctld; job starts
        │
        ▼
Node becomes idle / job finishes
        │
        ▼
SuspendProgram = suspend_wrapper.sh
        │
        ▼
suspend.py calls compute.instances.delete()
```

### 1. Deployment prepares templates, not all dynamic VMs

At deployment time, the controller module creates a Compute Engine instance template for every nodeset. Metadata on that template identifies the VM as a Slurm compute node and points it to the cluster’s GCS configuration bucket. The resulting template self-link and the static/dynamic node counts are written into the controller’s runtime configuration. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/partition.tf))

This means Cluster Toolkit/Terraform prepares the infrastructure definition, but it does **not** run Terraform every time a job arrives. After deployment, the per-job scaling path runs from `slurmctld` through the controller-side SlurmGCP scripts.

### 2. Slurm predeclares logical cloud nodes

The generated Slurm configuration creates node-name ranges with:

```text
NodeName=<generated range> State=CLOUD ...
```

It also configures:

```text
ResumeProgram=.../resume_wrapper.sh
ResumeFailProgram=.../suspend_wrapper.sh
SuspendProgram=.../suspend_wrapper.sh
ResumeTimeout=300
SuspendTimeout=300
```

These are logical Slurm nodes that can exist in the scheduler even when no corresponding VM currently exists. When Slurm assigns work to one of them, Slurm invokes `ResumeProgram` with the selected node names. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/conf.py))

### 3. Resume creates new instances with exact Slurm node names

`resume.py` reads `SLURM_RESUME_FILE`, which contains the job ID, partition and allocated node names. It groups requests according to nodeset, job and placement requirements. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/resume.py))

For ordinary VM nodes, it constructs a Bulk Insert request containing:

```python
{
    "count": len(nodes),
    "sourceInstanceTemplate": template,
    "perInstanceProperties": {
        "<slurm-node-name-1>": {},
        "<slurm-node-name-2>": {},
    },
}
```

With one allowed zone it calls zonal `instances.bulkInsert`; with multiple allowed zones it calls regional `regionInstances.bulkInsert` and supplies a location policy. This is important: the normal autoscaling path **creates fresh VMs**. It does not normally maintain and start a pool of stopped compute VMs. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/resume.py))

For placement-group allocations, the code deliberately omits `minCount`, producing all-or-nothing provisioning. For other allocations, it permits a partial result with `minCount=1`. This can materially affect large Spot allocations when capacity is fragmented. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/resume.py))

### 4. A newly created VM turns itself into a Slurm node

The instance-template startup script obtains `slurm_bucket_path` and `slurm_instance_role` from instance metadata, downloads the SlurmGCP scripts archive from GCS, and executes `setup.py`. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/internal/slurm-gcp/instance_template/files/startup_sh_unlinted))

For compute nodes, `setup.py`:

- configures `slurmd` to obtain configuration from the controller using `--conf-server`;
- installs custom scripts;
- configures NSS and network storage;
- starts Munge where applicable;
- enables and restarts `slurmd`.

Once `slurmd` registers, Slurm can launch the allocated job. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/setup.py))

This bootstrapping work explains why autoscaling has a nonzero cold-start time. If the image, package setup, mounts or custom scripts take longer than the configured `ResumeTimeout`, Slurm can mark the node down and invoke `ResumeFailProgram` for cleanup. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/conf.py))

### 5. Suspend deletes ordinary autoscaled VMs

When Slurm’s power-saving policy selects a node for suspension, `suspend.py` calls:

```python
compute.instances().delete(
    project=...,
    zone=...,
    instance=<node-name>,
)
```

Thus ordinary dynamic compute nodes are deleted rather than merely stopped. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/suspend.py))

The generated partition configuration has `SuspendTime=300`. When job exclusivity is enabled—which the partition module documents as the default—it sets `PowerDownOnIdle=YES`, so compute nodes can be removed immediately after an exclusive job finishes rather than waiting five minutes. Static node ranges are placed in `SuspendExcNodes` and are therefore excluded from this autosuspend behavior. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/conf.py))

## Enabling Spot compute nodes

A representative nodeset fragment is:

```yaml
- id: spot_nodes
  source: community/modules/compute/schedmd-slurm-gcp-v6-nodeset
  use:
  - network
  settings:
    machine_type: c2-standard-30

    # Scale from zero to at most 100 compute nodes.
    node_count_static: 0
    node_count_dynamic_max: 100

    # Use Google Cloud Spot provisioning.
    enable_spot_vm: true

    # Optional. STOP is the Google Cloud default.
    spot_instance_config:
      termination_action: STOP
```

This nodeset must then be connected to a `schedmd-slurm-gcp-v6-partition` and the controller in the complete blueprint.

The module passes `enable_spot_vm` into the internal template as `spot`. Internally, both the older `preemptible` setting and the newer Spot setting converge into:

```hcl
preemptible      = var.preemptible || var.spot
provisioning_model = local.preemptible ? "SPOT" : "STANDARD"
automatic_restart  = false  # for Spot/preemptible
```

The selected termination action is also written into the template scheduling block. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/compute/schedmd-slurm-gcp-v6-nodeset/main.tf))

For new configurations, `enable_spot_vm` is the clearer setting. The older `preemptible: true` input still reaches the same `SPOT` provisioning-model path in the current code. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/compute/schedmd-slurm-gcp-v6-nodeset/README.md))

## What happens when a Spot node is preempted

Spot preemption is different from normal Slurm scale-down.

### With `termination_action: STOP`

Google Cloud’s default behavior is to put the VM into `TERMINATED` state rather than delete it. ([cloud.google.com](https://cloud.google.com/compute/docs/instances/spot))

The controller’s `slurmsync.py` reconciliation code explicitly recognizes this condition:

1. The GCE instance exists but has status `TERMINATED`.
2. Its scheduling configuration is marked preemptible/Spot.
3. `slurmsync.py` selects `NodeActionPrempt`.
4. It marks the Slurm node `DOWN` with reason `Preempted instance`.
5. It calls `compute.instances().start()` on the existing VM. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/slurmsync.py))

So the exceptional lifecycle is:

```text
Spot VM preempted
    → GCE status TERMINATED
    → slurmsync marks Slurm node DOWN
    → instances.start(existing VM)
```

The restart can still fail if Spot capacity is unavailable. Also, restarting the VM does **not** restore the process state of the interrupted job.

### With `termination_action: DELETE`

Google Cloud removes the instance completely. The next reconciliation sees a Slurm node without a backing VM and moves it toward the powered-down/down state. A subsequent Slurm allocation can run the normal Resume/Bulk Insert path and create a fresh replacement VM. ([cloud.google.com](https://cloud.google.com/compute/docs/instances/spot))

The practical distinction is:

| Event | Compute behavior |
|---|---|
| Normal dynamic scale-up | Create a fresh VM with Bulk Insert |
| Normal dynamic scale-down | Delete the VM |
| Spot preemption with `STOP` | Stop existing VM; `slurmsync` attempts to start it again |
| Spot preemption with `DELETE` | Delete VM; later Slurm resume must create a replacement |

In both Spot cases, a running job can be interrupted. Job recovery therefore needs an appropriate Slurm requeue policy and, for meaningful long-running work, application checkpoint/restart support. Slurm supports requeueing jobs after node/resume failures, but the exact behavior depends on the job and cluster configuration. ([slurm.schedmd.com](https://slurm.schedmd.com/slurm.conf.html))

## Operational recommendations

Use a separate Spot nodeset and preferably a clearly named Spot partition. That makes interruption expectations explicit and lets users route only fault-tolerant jobs there.

Keep a Standard nodeset or partition for non-checkpointable jobs. I do not see an automatic “retry this Spot request as Standard” path in the current resume code: each request uses the fixed instance template associated with its nodeset, so a Spot nodeset continues to request Spot capacity. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/partition.tf))

Choose the termination action deliberately:

- `STOP` matches the existing `slurmsync.py` restart path and retains the VM and its persistent boot disk.
- `DELETE` better matches a purely ephemeral model, but recovery requires creation of another VM and appropriate job requeue handling.

For large Spot jobs, review placement policy and allowed zones. Placement-group requests can be all-or-nothing, while regional Bulk Insert can search across the configured zones. Disabling placement may improve acquisition probability for workloads that do not require tightly placed nodes, though it may reduce HPC network locality. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/compute/schedmd-slurm-gcp-v6-nodeset/README.md))

Finally, treat the Spot preemption notice as best effort. Google Cloud’s default dedicated notice delay is zero; shutdown handling then has a best-effort period of up to 30 seconds. Spot capacity is finite, can disappear at any time, and has no Compute Engine SLA. ([cloud.google.com](https://cloud.google.com/compute/docs/instances/spot))

---

## User

how can it support using container image as runtime env? that's very important to us

## Assistant

## Yes—use the container as the **per-job runtime**, not as the VM boot image

The intended architecture is:

```text
Compute Engine VM created by Slurm autoscaling
└── Host OS
    ├── slurmd
    ├── Linux kernel
    ├── GPU driver
    ├── RDMA / GPUDirect / NCCL host components
    ├── storage mounts
    └── container runtime
         └── Your application container
             ├── Python / Conda
             ├── application binaries
             ├── CUDA user-space libraries
             └── application dependencies
```

The `instance_image` setting on a Cluster Toolkit nodeset still refers to a **Compute Engine OS image**. You should not put an Artifact Registry or Docker image URI into `instance_image`. Instead, bake the container runtime into the Compute Engine image, and let each Slurm job select its workload container.

This works with autoscaled Standard or Spot compute nodes. Slurm first creates the VM, `slurmd` registers with the controller, and then the allocated job step launches inside the selected container.

## The two practical container options

| Runtime | Best fit | Job image format | Slurm integration |
|---|---|---|---|
| **Enroot + Pyxis** | GPU training, distributed ML, A3/A4 systems | Docker/OCI registry image or `.sqsh` | Native-looking `srun --container-image=...` |
| **Apptainer** | General HPC, CPU workloads, mixed clusters, portable environments | `.sif`, Docker/OCI, ORAS | `srun apptainer exec ...` |

### Enroot + Pyxis

Pyxis is a Slurm SPANK plugin that adds options such as `--container-image`, `--container-mounts`, `--container-env`, and `--container-readonly` directly to `srun` and `sbatch`. It supports unprivileged containers and multi-node PMI2/PMIx jobs. ([github.com](https://github.com/nvidia/pyxis))

Current Google Cloud AI Hypercomputer Slurm images for accelerator systems include Enroot and Pyxis, along with the NVIDIA Container Toolkit, GPU drivers, MPI, and PMIx. ([docs.cloud.google.com](https://docs.cloud.google.com/ai-hypercomputer/docs/images?utm_source=chatgpt.com))

This is the strongest choice when your workload is:

- PyTorch, JAX, TensorFlow or NVIDIA NGC based
- Multi-node and multi-GPU
- Running on A3, A4 or related accelerator blueprints
- Already packaged as a Docker/OCI image

### Apptainer

The repository includes a generic `hpc-slurm6-apptainer.yaml` blueprint. It builds a custom Slurm Compute Engine image with Apptainer installed, then uses that custom image for compute, login, and controller nodes. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/examples/hpc-slurm6-apptainer.yaml))

The AlphaFold 3 Slurm example follows the same model: it installs Apptainer and the NVIDIA host driver into the custom VM image, stores the application as a SIF, binds data and output directories, and runs the workload with `apptainer run --nv`. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/examples/science/af3-slurm/adm/apptainer_image.yml))

This is the safer general default when you are not specifically using one of the GPU-optimized A3/A4 blueprints.

## Option 1: add Apptainer to a generic autoscaling nodeset

This is based on the official Toolkit example, with Spot and scale-to-zero added:

```yaml
blueprint_name: slurm-container-runtime

vars:
  project_id: YOUR_PROJECT_ID
  deployment_name: slurm-containers
  region: us-central1
  zone: us-central1-c

  custom_image:
    family: slurm-apptainer
    project: $(vars.project_id)

  disk_size_gb: 64

deployment_groups:
- group: base
  modules:
  - id: network
    source: modules/network/vpc

  - id: install_container_runtime
    source: modules/scripts/startup-script
    settings:
      runners:
      - type: shell
        destination: install_apptainer.sh
        content: |
          #!/bin/bash
          set -euo pipefail

          dnf install -y epel-release
          dnf install -y apptainer

- group: image
  modules:
  - id: slurm_apptainer_image
    source: modules/packer/custom-image
    kind: packer
    use:
    - network
    - install_container_runtime
    settings:
      source_image_project_id:
      - schedmd-slurm-public

      # Use the currently published family matching your
      # pinned Cluster Toolkit / Slurm-GCP release.
      source_image_family: slurm-gcp-6-12-hpc-rocky-linux-9

      image_family: $(vars.custom_image.family)
      disk_size: $(vars.disk_size_gb)
      state_timeout: 15m

- group: cluster
  modules:
  - id: compute_nodeset
    source: community/modules/compute/schedmd-slurm-gcp-v6-nodeset
    use:
    - network
    settings:
      node_count_static: 0
      node_count_dynamic_max: 100

      enable_spot_vm: true

      instance_image: $(vars.custom_image)
      disk_size_gb: $(vars.disk_size_gb)
      allow_automatic_updates: false

  - id: compute_partition
    source: community/modules/compute/schedmd-slurm-gcp-v6-partition
    use:
    - compute_nodeset
    settings:
      partition_name: container
      is_default: true

  - id: slurm_login
    source: community/modules/scheduler/schedmd-slurm-gcp-v6-login
    use:
    - network
    settings:
      name_prefix: login
      enable_login_public_ips: true
      instance_image: $(vars.custom_image)
      disk_size_gb: $(vars.disk_size_gb)

  - id: slurm_controller
    source: community/modules/scheduler/schedmd-slurm-gcp-v6-controller
    use:
    - network
    - compute_partition
    - slurm_login
    settings:
      enable_controller_public_ips: true
      instance_image: $(vars.custom_image)
      disk_size_gb: $(vars.disk_size_gb)
```

Using the custom image for login nodes is useful because users can test containers there. Using the same image everywhere also avoids runtime-version inconsistencies.

## Running an Apptainer job

Assume your application image is stored as:

```text
/shared/containers/myapp-20260727.sif
```

A CPU job could be:

```bash
#!/bin/bash
#SBATCH --job-name=myapp
#SBATCH --partition=container
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --time=02:00:00
#SBATCH --output=logs/%x-%j.out

set -euo pipefail

IMAGE=/shared/containers/myapp-20260727.sif

srun apptainer exec \
  --bind /shared/input:/input:ro \
  --bind /shared/output:/output \
  "${IMAGE}" \
  python /app/run.py \
    --input /input/request.json \
    --output /output
```

For an NVIDIA GPU job:

```bash
#!/bin/bash
#SBATCH --job-name=gpu-container
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --gres=gpu:1
#SBATCH --mem=128G
#SBATCH --time=04:00:00

set -euo pipefail

IMAGE=/shared/containers/training-20260727.sif

srun apptainer exec \
  --nv \
  --bind /shared/datasets:/datasets:ro \
  --bind /shared/checkpoints:/checkpoints \
  "${IMAGE}" \
  python /workspace/train.py \
    --data /datasets \
    --checkpoint-dir /checkpoints
```

Apptainer’s `--nv` option makes the host NVIDIA device nodes and appropriate host driver libraries available inside the container. The host must therefore have a working GPU driver, while the container can provide PyTorch, CUDA user-space libraries, and the application stack. ([apptainer.org](https://apptainer.org/docs/user/main/gpu.html?utm_source=chatgpt.com))

For stricter environment reproducibility, add `--cleanenv` and explicitly pass required variables with `--env` or an environment file.

## Option 2: Enroot + Pyxis for GPU and distributed ML

For A3/A4 GPU clusters, this normally gives the cleanest user experience.

The current accelerator blueprints configure Enroot cache, data, runtime, and temporary paths on local SSD, and some explicitly install the Pyxis SPANK configuration. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/examples/machine-learning/a4x-highgpu-4g/a4xhigh-slurm-blueprint.yaml))

### Prepare an image

Pyxis can import an OCI image directly, but for autoscaled clusters I recommend converting it once into an immutable SquashFS file.

For example:

```bash
srun -N 1 enroot import \
  docker://nvcr.io#nvidia/pytorch:24.04-py3
```

This produces a file similar to:

```text
nvidia+pytorch+24.04-py3.sqsh
```

Google’s A3 Mega instructions use this exact approach before running the image through Pyxis. ([docs.cloud.google.com](https://docs.cloud.google.com/cluster-toolkit/docs/machine-learning/a3-mega-enable-gpudirect-tcpxo?utm_source=chatgpt.com))

Place the resulting file on shared storage:

```text
/shared/containers/pytorch-24.04-py3.sqsh
```

### Run the container through Pyxis

```bash
#!/bin/bash
#SBATCH --job-name=distributed-train
#SBATCH --partition=a3
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=8
#SBATCH --gpus-per-node=8
#SBATCH --exclusive
#SBATCH --time=04:00:00
#SBATCH --output=logs/%x-%j.out

set -euo pipefail

IMAGE=/shared/containers/pytorch-24.04-py3.sqsh

srun \
  --container-image="${IMAGE}" \
  --container-readonly \
  --no-container-mount-home \
  --container-mounts=/shared/datasets:/datasets:ro,/shared/checkpoints:/checkpoints \
  python /workspace/train.py \
    --dataset /datasets \
    --checkpoint-dir /checkpoints
```

Pyxis accepts either an Enroot-compatible registry URI or a path to a SquashFS image. It also supports read-only containers, explicit mounts, environment propagation and multi-node MPI through PMI2 or PMIx. ([github.com](https://github.com/nvidia/pyxis))

It can also be put into the batch directives:

```bash
#!/bin/bash
#SBATCH --partition=a3
#SBATCH --nodes=1
#SBATCH --gpus-per-node=8
#SBATCH --container-image=/shared/containers/pytorch-24.04-py3.sqsh
#SBATCH --container-readonly
#SBATCH --container-mounts=/shared/data:/data:ro,/shared/output:/output

python /workspace/train.py
```

When referring directly to a registry in an `#SBATCH` line, Pyxis uses `REGISTRY#IMAGE`, and the `#` must be escaped because it otherwise starts a shell comment:

```bash
#SBATCH --container-image=nvcr.io\#nvidia/pytorch:24.04-py3
```

## Recommended image supply chain

Keep your existing Docker workflow as the source of truth:

```text
Dockerfile
    │
    ▼
Build OCI image
    │
    ▼
Push to Artifact Registry
    │
    ├── Enroot import → immutable .sqsh
    │
    └── Apptainer build → immutable .sif
             │
             ▼
Shared container repository
             │
             ▼
Slurm job references versioned image path
```

The Cluster Toolkit AlphaFold example demonstrates a similar CI pattern: Cloud Build creates and pushes a Docker image, converts it into a SIF with Apptainer, and pushes the SIF as an ORAS artifact. ([github.com](https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/examples/science/af3-slurm/adm/apptainer_cloudbuild.yaml?utm_source=chatgpt.com))

Use immutable names or digests, for example:

```text
/shared/containers/myapp/
├── sha256-e14c...8af.sif
└── sha256-e14c...8af.sqsh
```

Avoid making production jobs depend on a mutable `latest` tag. Otherwise, two nodes starting at different times could run different application contents.

## Container image placement matters for autoscaling and Spot

A direct registry pull at the beginning of every job is simple, but it can become expensive operationally:

```text
Job queued
  → VM boots
  → slurmd registers
  → every node downloads a 10–30 GB image
  → container is unpacked
  → application finally starts
```

For scale-to-zero and Spot nodes, treat every node-local container cache as disposable. A replacement node might have no cached layers.

A better production design is:

1. Store the immutable `.sif` or `.sqsh` on Managed Lustre, Filestore, NFS, or another shared filesystem.
2. At job start, copy it to local SSD only when the digest is not already present.
3. Use `flock` or another lock so several tasks on the same node do not copy the same image simultaneously.
4. Run the container from local SSD.
5. Write checkpoints and outputs only to shared or persistent storage.

A staging wrapper might look like:

```bash
#!/bin/bash
set -euo pipefail

SOURCE_IMAGE=/shared/containers/myapp-sha256-e14c.sqsh
LOCAL_DIR=/mnt/localssd/containers
LOCAL_IMAGE="${LOCAL_DIR}/$(basename "${SOURCE_IMAGE}")"

mkdir -p "${LOCAL_DIR}"

(
  flock 9

  if [[ ! -f "${LOCAL_IMAGE}" ]]; then
    temporary="${LOCAL_IMAGE}.tmp.$$"
    cp "${SOURCE_IMAGE}" "${temporary}"
    mv "${temporary}" "${LOCAL_IMAGE}"
  fi
) 9>"${LOCAL_IMAGE}.lock"

exec srun \
  --container-image="${LOCAL_IMAGE}" \
  --container-readonly \
  --container-mounts=/shared/data:/data:ro,/shared/checkpoints:/checkpoints \
  python /workspace/train.py
```

For especially large images that change infrequently, another option is to bake the `.sif` or `.sqsh` into the custom Compute Engine image. That minimizes cold-start latency but makes application releases require rebuilding the VM image.

## GPU and high-performance networking caveats

The application container does not replace host-level GPU and network configuration.

The host should contain:

- NVIDIA kernel driver
- NVIDIA Container Toolkit or Apptainer GPU integration
- RDMA or GPUDirect components
- machine-specific NCCL network plugin
- `slurmd`, PMIx and required Slurm plugins
- filesystem clients

The container should contain:

- application code
- framework such as PyTorch or JAX
- compatible CUDA user-space libraries
- Python and application dependencies
- MPI libraries when required by the selected launch model

For A3 and A4 multi-node workloads, certain host network libraries, sockets, device paths, and environment variables must be passed into the container. Google’s NCCL examples use `--container-env` and `--container-mounts` to expose the TCPX or TCPXO libraries and configuration to Enroot containers. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/examples/machine-learning/a3-megagpu-8g/nccl-tests/run-nccl-tests.sh))

A simplified example is:

```bash
export NCCL_SOCKET_IFNAME=enp0s12
export NCCL_DEBUG=INFO

srun \
  --container-image="${IMAGE}" \
  --container-env=NCCL_SOCKET_IFNAME,NCCL_DEBUG \
  --container-mounts=/var/lib/tcpxo/lib64:/var/lib/tcpxo/lib64,/shared:/shared \
  /workspace/train
```

Use the environment and mount configuration from the exact Cluster Toolkit accelerator blueprint rather than copying settings between A3 High, A3 Mega, A3 Ultra and A4 systems; their optimized networking stacks differ.

## Spot behavior

The container model works identically on Spot compute nodes, but the container does not make Spot interruption transparent.

When a running Spot VM is reclaimed:

```text
VM interrupted
  → container processes terminate
  → Slurm job step fails
  → VM may be restarted or replaced
  → job must be requeued
  → application must resume from persistent checkpoint
```

Therefore:

- enable appropriate Slurm requeue behavior;
- checkpoint to shared persistent storage;
- make job startup idempotent;
- reference an immutable image;
- never keep the only copy of results or checkpoints on the container filesystem or local SSD.

## Security boundary

Enroot and Pyxis run workloads without requiring users to start a privileged Docker daemon. However, Enroot deliberately provides relatively little isolation in exchange for HPC performance and simplicity; it should not be treated as a strong hostile-tenant security boundary. ([github.com](https://github.com/NVIDIA/enroot/blob/main/README.md))

For shared clusters, use:

```text
read-only container root
+ no automatic home mount
+ explicit bind mounts
+ least-privilege VM service account
+ no Docker socket inside jobs
+ Slurm CPU, memory and GPU limits
```

## Recommended choice

For **GPU or distributed AI training on A3/A4**, use **Enroot + Pyxis**, store a pre-imported immutable `.sqsh` on shared storage, and stage it onto local SSD per node.

For **general CPU/HPC or mixed workloads**, use the official **Apptainer custom-image pattern**, keep application environments as immutable `.sif` files, and invoke them with `srun apptainer exec`.

In both designs, the Compute Engine image owns Slurm, drivers, networking and the container runtime; the workload image owns your application environment.

---

## User

if on my dev box, I only has non-sudo account, am I required to ssh to a in-cluster head node to submit job/debug jobs interactively? can we run a srun user-space client?

## Assistant

## Recommended answer

**You do not need to SSH to the Slurm controller/head node.** In fact, normal users should not use the controller as a development host. Cluster Toolkit creates a separate **login node**, which is the intended submission and interactive access point. Google’s current Cluster Toolkit instructions explicitly direct users to the login node, commonly through IAP. ([docs.cloud.google.com](https://docs.cloud.google.com/cluster-toolkit/docs/deploy/slurm/create-a3-high-cluster))

For your use case:

- **Batch submission, status, and cancellation:** an interactive SSH session is not required.
- **Interactive `srun --pty` debugging:** the practical design is to execute `srun` on the in-cluster login node, possibly through a single remote SSH command.
- **Running a real `srun` process on your non-sudo dev box:** technically possible, but only after an administrator turns that box into a trusted, routable Slurm submit host. Installing the `srun` binary in `$HOME` is not sufficient.

## Why a user-space `srun` binary is not enough

A Slurm client needs three things in addition to the executable.

### 1. Slurm authentication

Current Cluster Toolkit code supports either:

```text
AuthType=auth/slurm
```

or the MUNGE fallback:

```text
AuthType=auth/munge
```

and its generated configuration also enables JWT as an alternate client authentication mechanism:

```text
AuthAltTypes=auth/jwt
```

The current login-node setup starts `sackd`; when native Slurm authentication is disabled, it also starts MUNGE. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/etc/slurm.conf.tpl))

With native `auth/slurm`, a submit host normally runs `sackd`. That daemon runs as `SlurmUser` and needs access to the cluster’s shared `slurm.key` or JWKS file. With MUNGE, the submit host needs the cluster MUNGE key and a running `munged`. Those keys are deliberately not readable by an ordinary user. ([slurm.schedmd.com](https://slurm.schedmd.com/sackd.html))

Therefore, as a non-sudo user, you generally cannot independently turn your dev machine into an authenticated Slurm submit host. An administrator would have to:

- install and configure `sackd` or MUNGE;
- place the cluster authentication key on the machine;
- maintain compatible Slurm client binaries;
- establish the corresponding Unix identity.

That also changes the trust boundary. SchedMD warns that putting cluster security keys on user-controlled workstations has security implications, because the workstation’s root administrator could access those keys and potentially submit work with elevated cluster identities. ([slurm.schedmd.com](https://slurm.schedmd.com/quickstart_admin.html))

### 2. Network connectivity

Most ordinary Slurm client commands only need to contact `slurmctld`, whose default port is TCP 6817:

```text
sbatch
squeue
sinfo
scancel
scontrol
```

`srun` is different. After obtaining an allocation, it opens sockets for job I/O, and `slurmstepd` on the compute nodes connects back to the machine where `srun` is running. Slurm consequently requires bidirectional IP connectivity from any host on which `srun` executes. Its I/O ports are normally selected from the ephemeral range, although the administrator can constrain them with `SrunPortRange`. ([slurm.schedmd.com](https://slurm.schedmd.com/network.html))

That means a laptop or ordinary development box behind NAT cannot normally run a native interactive `srun`, even if it can reach port 6817 through a VPN or SSH forward:

```text
dev box srun
    │
    ├── outbound → slurmctld:6817       usually possible
    │
    └── inbound  ← compute/slurmstepd   usually blocked
```

A single SSH tunnel to the controller does not provide this callback path. To make local `srun` work, your dev box would need a private, routable address visible from every dynamic compute VM and firewall rules allowing the configured `SrunPortRange`.

### 3. Cluster-visible files and identity

The username—and normally UID/GID—must resolve correctly inside the cluster. The program, working directory, container image, input data, and output directories must also exist on paths visible to the compute nodes.

Even `sbatch` only transfers the batch script itself. It does not copy application code or input files. ([slurm.schedmd.com](https://slurm.schedmd.com/sbatch.html))

## Best operational model

Use this topology:

```text
Developer box
    │
    │ SSH/IAP
    ▼
Private Slurm login node
    ├── authenticated Slurm client
    ├── sackd or MUNGE
    ├── shared /home and /shared mounts
    └── srun process remains here
             │
             ▼
       slurmctld
             │
             ▼
     autoscaled compute VM
             └── workload container
```

The login VM can be relatively small and always available. The expensive Standard or Spot compute VMs still scale from zero only when jobs request them.

## No interactive SSH shell for batch jobs

You can submit a local batch script through SSH without opening a shell:

```bash
ssh slurm-login \
  'sbatch --parsable --chdir=/shared/work/my-project' \
  < train.sbatch
```

Because no script filename is passed, the remote `sbatch` reads the script from standard input. Slurm then returns the job ID. ([slurm.schedmd.com](https://slurm.schedmd.com/sbatch.html))

Query jobs:

```bash
ssh slurm-login 'squeue -u "$USER"'
```

Inspect accounting:

```bash
ssh slurm-login 'sacct -j 123456'
```

Cancel a job:

```bash
ssh slurm-login 'scancel 123456'
```

Tail job output:

```bash
ssh slurm-login \
  'tail -f /shared/work/my-project/logs/train-123456.out'
```

This gives you a local-CLI-like workflow while keeping the Slurm authentication key and Slurm network connections inside the trusted cluster.

The job script, application code, container image, and data should use cluster-visible paths such as:

```text
/shared/work/my-project
/shared/containers/training.sqsh
/shared/datasets
/shared/checkpoints
```

Alternatively, the script can fetch immutable application content from Git or Cloud Storage at job startup.

## Interactive debugging from the dev box

Run remote `srun` with SSH pseudo-terminal forwarding:

```bash
ssh -tt slurm-login \
  'srun \
      --partition=debug \
      --nodes=1 \
      --ntasks=1 \
      --cpus-per-task=8 \
      --mem=32G \
      --time=01:00:00 \
      --pty bash -l'
```

The important point is:

```text
terminal is on your dev box
srun process is on the login node
debug shell is on the compute node
```

This feels interactive locally but satisfies Slurm’s authentication and callback networking requirements.

Because the partition is autoscaled, `srun` may initially remain pending while Cluster Toolkit creates and boots the compute VM. Once `slurmd` registers, the shell starts.

### Interactive Pyxis container

```bash
ssh -tt slurm-login \
  'srun \
      --partition=debug \
      --nodes=1 \
      --ntasks=1 \
      --gpus=1 \
      --cpus-per-task=16 \
      --mem=128G \
      --time=01:00:00 \
      --container-image=/shared/containers/dev.sqsh \
      --container-mounts=/shared/work:/work,/shared/data:/data \
      --pty bash -l'
```

You arrive directly inside the container on the allocated compute node.

### Interactive Apptainer container

```bash
ssh -tt slurm-login \
  'srun \
      --partition=debug \
      --nodes=1 \
      --ntasks=1 \
      --gpus=1 \
      --cpus-per-task=16 \
      --mem=128G \
      --time=01:00:00 \
      --pty \
      apptainer exec \
        --nv \
        --bind /shared/work:/work \
        --bind /shared/data:/data \
        /shared/containers/dev.sif \
        bash -l'
```

For Spot debugging, remember that an interactive session disappears when the Spot VM is reclaimed.

## Make remote `srun` look like a local command

A Bash wrapper on the dev box can preserve argument quoting and execute `srun` remotely:

```bash
cluster_srun() {
    local quoted
    printf -v quoted '%q ' "$@"
    ssh -tt slurm-login "exec srun ${quoted}"
}
```

Usage:

```bash
cluster_srun \
  --partition=debug \
  --nodes=1 \
  --cpus-per-task=8 \
  --mem=32G \
  --time=01:00:00 \
  --pty bash -l
```

For a container:

```bash
cluster_srun \
  --partition=debug \
  --nodes=1 \
  --gpus=1 \
  --time=01:00:00 \
  --container-image=/shared/containers/dev.sqsh \
  --container-mounts=/shared/work:/work \
  --pty bash -l
```

This is not a local Slurm client—the `srun` process still executes on the login node—but from a developer-experience perspective it behaves almost the same.

## Surviving SSH disconnects

An ordinary `srun --pty` can terminate when its controlling SSH connection disappears. For longer debugging sessions, first create a persistent terminal on the login node:

```bash
ssh -tt slurm-login 'tmux new-session -A -s slurm-debug'
```

Then, inside `tmux`:

```bash
srun \
  --partition=debug \
  --nodes=1 \
  --time=04:00:00 \
  --pty bash -l
```

After a network interruption, reconnect using the same command:

```bash
ssh -tt slurm-login 'tmux new-session -A -s slurm-debug'
```

For reproducible work, still write source changes, logs, and checkpoints to shared storage rather than relying on the interactive compute node.

## Can JWT provide a completely local client?

**For noninteractive commands, yes. For interactive `srun`, no.**

The current Cluster Toolkit template includes:

```text
AuthAltTypes=auth/jwt
```

A Slurm client installed under your home directory could therefore potentially run:

```bash
SLURM_JWT="$TOKEN" sbatch train.sbatch
SLURM_JWT="$TOKEN" squeue -u myuser
SLURM_JWT="$TOKEN" scancel 123456
```

provided that:

1. the client is built with JWT support and is compatible with the cluster;
2. it can reach `slurmctld` on port 6817;
3. it has a suitable `slurm.conf` or configless configuration source;
4. it receives a short-lived token mapping to the correct cluster user;
5. all referenced paths exist in the cluster.

Slurm’s own documentation shows JWT-authenticated `sbatch`, and user tokens can have a limited lifetime; the default generated-token lifetime is 1,800 seconds. ([slurm.schedmd.com](https://slurm.schedmd.com/jwt.html))

However, Slurm explicitly states that **interactive jobs using `srun` are not supported when the client uses `auth/jwt` or has `SLURM_JWT` set**. JWT only supports client-to-controller or client-to-database communication; it does not authenticate all the bidirectional job-step traffic needed by interactive `srun`. ([slurm.schedmd.com](https://slurm.schedmd.com/jwt.html))

Do not distribute the JWT signing key to developer machines. A service trusted to sign arbitrary Slurm JWTs effectively has cluster-wide root-level authority. Developer machines should receive only short-lived, user-specific tokens. ([slurm.schedmd.com](https://slurm.schedmd.com/jwt.html))

## REST API alternative for batch workflows

Current Cluster Toolkit controller setup enables and starts `slurmrestd`, and the generated configuration enables JWT authentication. ([raw.githubusercontent.com](https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/setup.py))

That permits an architecture such as:

```text
Developer CLI / CI
      │
      │ HTTPS + company identity
      ▼
Authenticated submission gateway
      │
      │ short-lived mapped Slurm identity
      ▼
slurmrestd
      │
      ▼
slurmctld
```

The developer-facing API could support:

```text
cluster submit train.sbatch
cluster jobs
cluster logs JOB_ID
cluster cancel JOB_ID
```

`slurmrestd` supports JWT-authenticated requests and HTTPS/TLS, and can submit job scripts programmatically. ([slurm.schedmd.com](https://slurm.schedmd.com/slurmrestd.html))

This is a good choice for CI, automation, IDE integrations, and users who should not receive SSH access. It is not a substitute for an interactive terminal: an interactive debugging shell still needs SSH or another terminal gateway into an in-cluster login environment.

## When a genuine dev-box `srun` makes sense

A true local `srun` is reasonable only when the “dev box” is actually a centrally managed submit host, for example:

```text
managed GCE development VM
+ same private VPC as the cluster
+ stable private IP
+ matching Unix identities
+ administrator-managed Slurm packages
+ administrator-managed sackd
+ protected slurm.key
+ compute-to-dev firewall rules
+ configured SrunPortRange
+ shared filesystem mounts
```

At that point, the dev box is operationally another Slurm login node. A personal laptop, arbitrary workstation, or unmanaged multi-user development server should not normally receive the cluster authentication key.

## Architecture I would use

Use both access paths:

```text
Batch / CI:
    local CLI → HTTPS/JWT API
          or
    local CLI → SSH remote sbatch

Interactive:
    local terminal → SSH/IAP → login node → srun --pty → compute node
```

Keep the controller private and unavailable for ordinary SSH. Keep the login node private as well and access it through OS Login plus IAP:

```bash
gcloud compute ssh CLUSTER-login-001 \
  --zone=ZONE \
  --tunnel-through-iap
```

Google documents this login-node access pattern directly. ([docs.cloud.google.com](https://docs.cloud.google.com/cluster-toolkit/docs/deploy/slurm/create-a3-high-cluster))

The central distinction is that a **user-space Slurm client is easy to package, but an authenticated, bidirectionally connected `srun` host is infrastructure**. For interactive work, executing `srun` remotely on the login node gives you the desired development experience without extending the cluster’s credential and networking trust boundary to every developer machine.

---

## User

Export this conversation as a zip file, especially related doc/links/design, I will ask my codex to read it
