# Source Links Mentioned in the Conversation

These links were cited or discussed in the visible conversation. They should be revalidated against the exact pinned Cluster Toolkit/Slurm version. GitHub `main` URLs are inherently moving targets.

## Cluster Toolkit: nodesets, controller, and autoscaling

1. Slurm v6 nodeset module README  
   https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/compute/schedmd-slurm-gcp-v6-nodeset/README.md

2. Slurm v6 nodeset module implementation  
   https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/compute/schedmd-slurm-gcp-v6-nodeset/main.tf

3. Slurm v6 controller partition template wiring  
   https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/partition.tf

4. Generated Slurm configuration logic (`conf.py`)  
   https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/conf.py

5. Dynamic resume implementation (`resume.py`)  
   https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/resume.py

6. Dynamic suspend implementation (`suspend.py`)  
   https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/suspend.py

7. Controller reconciliation and Spot/preempted-node handling (`slurmsync.py`)  
   https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/slurmsync.py

8. Instance-template startup script  
   https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/internal/slurm-gcp/instance_template/files/startup_sh_unlinted

9. Slurm node setup implementation (`setup.py`)  
   https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/scripts/setup.py

10. Generated `slurm.conf` template  
    https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/community/modules/scheduler/schedmd-slurm-gcp-v6-controller/modules/slurm_files/etc/slurm.conf.tpl

## Google Cloud Spot and Cluster Toolkit guidance

11. Compute Engine Spot VMs  
    https://cloud.google.com/compute/docs/instances/spot

12. Cluster Toolkit A3 High Slurm deployment/login-node guidance  
    https://docs.cloud.google.com/cluster-toolkit/docs/deploy/slurm/create-a3-high-cluster

13. AI Hypercomputer images  
    https://docs.cloud.google.com/ai-hypercomputer/docs/images

14. A3 Mega GPUDirect TCPXO enablement  
    https://docs.cloud.google.com/cluster-toolkit/docs/machine-learning/a3-mega-enable-gpudirect-tcpxo

## Container runtimes and Toolkit examples

15. NVIDIA Pyxis  
    https://github.com/NVIDIA/pyxis

16. NVIDIA Enroot  
    https://github.com/NVIDIA/enroot/blob/main/README.md

17. Cluster Toolkit Apptainer Slurm example  
    https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/community/examples/hpc-slurm6-apptainer.yaml

18. AlphaFold 3 Apptainer image setup  
    https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/examples/science/af3-slurm/adm/apptainer_image.yml

19. AlphaFold 3 Apptainer Cloud Build pipeline  
    https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/examples/science/af3-slurm/adm/apptainer_cloudbuild.yaml

20. A4X Slurm blueprint with accelerator/container integration  
    https://github.com/GoogleCloudPlatform/cluster-toolkit/blob/main/examples/machine-learning/a4x-highgpu-4g/a4xhigh-slurm-blueprint.yaml

21. A3 Mega NCCL test launch script  
    https://raw.githubusercontent.com/GoogleCloudPlatform/cluster-toolkit/main/examples/machine-learning/a3-megagpu-8g/nccl-tests/run-nccl-tests.sh

22. Apptainer GPU support  
    https://apptainer.org/docs/user/main/gpu.html

## Slurm documentation

23. `slurm.conf` reference  
    https://slurm.schedmd.com/slurm.conf.html

24. `sackd`  
    https://slurm.schedmd.com/sackd.html

25. Slurm administration/security quick start  
    https://slurm.schedmd.com/quickstart_admin.html

26. Slurm networking requirements  
    https://slurm.schedmd.com/network.html

27. `sbatch`  
    https://slurm.schedmd.com/sbatch.html

28. JWT authentication  
    https://slurm.schedmd.com/jwt.html

29. `slurmrestd`  
    https://slurm.schedmd.com/slurmrestd.html
