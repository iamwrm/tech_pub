# Examples

These files are illustrative starting points. They intentionally contain placeholders such as `YOUR_PROJECT_ID`, `sha256-REPLACE`, and generic partition names.

Before use:

1. pin a Cluster Toolkit release/commit;
2. validate module sources and settings;
3. adapt machine type, zones, storage, identity, and networking;
4. use the exact container/GPU integration from the selected accelerator blueprint;
5. test in a non-production project.
