#!/usr/bin/env bash
# Stream a local batch script to sbatch on the in-cluster login node.
# Usage:
#   ./cluster_submit.sh train.sbatch [/shared/work/project]

set -euo pipefail

LOGIN_HOST=${SLURM_LOGIN_HOST:-slurm-login}
SCRIPT=${1:?usage: cluster_submit.sh SCRIPT [REMOTE_WORKDIR]}
REMOTE_WORKDIR=${2:-/shared/work}

if [[ ! -r "$SCRIPT" ]]; then
  echo "cannot read batch script: $SCRIPT" >&2
  exit 66
fi

# Quote the remote working directory for the remote shell.
printf -v QDIR '%q' "$REMOTE_WORKDIR"
exec ssh "$LOGIN_HOST" "exec sbatch --parsable --chdir=${QDIR}" < "$SCRIPT"
