#!/usr/bin/env bash
# Execute the real srun on an in-cluster login node while keeping the local TTY.
# Usage:
#   ./cluster_srun.sh --partition=debug --time=01:00:00 --pty bash -l

set -euo pipefail

LOGIN_HOST=${SLURM_LOGIN_HOST:-slurm-login}

if (($# == 0)); then
  echo "usage: $0 [srun arguments...]" >&2
  exit 64
fi

# Bash %q preserves each argument through the remote shell.
printf -v REMOTE_ARGS '%q ' "$@"
exec ssh -tt "$LOGIN_HOST" "exec srun ${REMOTE_ARGS}"
