#!/usr/bin/env bash
# Example node-local staging for an immutable Enroot/Pyxis .sqsh artifact.
# Run within an allocation and adapt LOCAL_DIR to the exact blueprint.

set -euo pipefail

SOURCE_IMAGE=${SOURCE_IMAGE:-/shared/containers/myapp/sha256-REPLACE.sqsh}
LOCAL_DIR=${LOCAL_CONTAINER_DIR:-/mnt/localssd/containers}
LOCAL_IMAGE="$LOCAL_DIR/$(basename "$SOURCE_IMAGE")"
EXPECTED_SHA256=${EXPECTED_SHA256:-REPLACE_WITH_SHA256}

mkdir -p "$LOCAL_DIR"

(
  flock 9
  if [[ ! -f "$LOCAL_IMAGE" ]]; then
    tmp="$LOCAL_IMAGE.tmp.$$"
    cp --reflink=auto "$SOURCE_IMAGE" "$tmp"
    actual=$(sha256sum "$tmp" | awk '{print $1}')
    if [[ "$EXPECTED_SHA256" != "REPLACE_WITH_SHA256" && "$actual" != "$EXPECTED_SHA256" ]]; then
      rm -f "$tmp"
      echo "container checksum mismatch" >&2
      exit 65
    fi
    mv "$tmp" "$LOCAL_IMAGE"
  fi
) 9>"$LOCAL_IMAGE.lock"

exec srun \
  --container-image="$LOCAL_IMAGE" \
  --container-readonly \
  --container-mounts=/shared/data:/data:ro,/shared/checkpoints:/checkpoints \
  python /workspace/train.py
