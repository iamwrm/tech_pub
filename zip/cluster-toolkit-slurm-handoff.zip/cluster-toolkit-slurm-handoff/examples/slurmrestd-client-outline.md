# `slurmrestd` Client/Gateway Outline

Use this path for batch automation, CI, and IDE integration—not as a replacement for interactive `srun`.

```text
Developer/CI
    |
    | company OIDC / mTLS / SSH certificate
    v
Submission gateway
    - authenticates company identity
    - maps identity to an allowed Slurm user/account/QOS
    - obtains or brokers short-lived Slurm credentials
    - validates job requests and paths
    - records an audit trail
    |
    | private TLS
    v
slurmrestd
    |
    v
slurmctld
```

Suggested developer-facing commands:

```text
cluster submit FILE [--project DIR]
cluster jobs [--mine]
cluster show JOB_ID
cluster cancel JOB_ID
cluster logs JOB_ID [-f]
```

Security requirements:

- never expose the Slurm JWT signing key to clients;
- use short-lived, user-scoped credentials;
- allowlist partitions/accounts/QOS and resource bounds;
- terminate TLS at a controlled gateway or directly with a verified configuration;
- do not accept arbitrary host filesystem paths without policy;
- make artifact upload/synchronization explicit;
- rate-limit and audit requests;
- validate the exact Slurm OpenAPI version before generating a client.
