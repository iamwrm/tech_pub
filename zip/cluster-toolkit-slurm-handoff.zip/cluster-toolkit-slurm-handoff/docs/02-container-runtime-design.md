# Container Runtime Design

## Separation of responsibilities

The Compute Engine VM image and the workload container serve different purposes.

### Host VM image

- Linux kernel and host OS
- `slurmd`, Slurm plugins, and configless client support
- GPU kernel driver
- RDMA/GPUDirect/NCCL host components
- filesystem clients and mounts
- Apptainer or Enroot/Pyxis runtime
- authentication helpers and monitoring agents

### Workload container

- application and entry point
- Python/Conda/language runtime
- ML/HPC framework
- user-space CUDA libraries compatible with the host driver
- application dependencies

`instance_image` in a Cluster Toolkit nodeset selects a Compute Engine OS image. It must not be set to an Artifact Registry/Docker image URI.

## Runtime choices

| Runtime | Best fit | Image forms | Slurm usage |
|---|---|---|---|
| Enroot + Pyxis | GPU and distributed AI; NGC/OCI workflows | OCI registry reference or immutable `.sqsh` | `srun --container-image=...` |
| Apptainer | General HPC, CPU/mixed workloads, portable artifacts | `.sif`, OCI/ORAS sources | `srun apptainer exec ...` |

## Enroot + Pyxis

Pyxis is a Slurm SPANK plugin. It makes container selection part of `srun`/`sbatch`, with options such as:

```text
--container-image
--container-mounts
--container-env
--container-readonly
--no-container-mount-home
```

This is usually the best developer experience for multi-node GPU training when the chosen accelerator blueprint already includes the NVIDIA host networking and runtime integration.

Illustrative launch:

```bash
srun \
  --container-image=/shared/containers/training-by-digest.sqsh \
  --container-readonly \
  --no-container-mount-home \
  --container-mounts=/shared/data:/data:ro,/shared/checkpoints:/checkpoints \
  python /workspace/train.py
```

## Apptainer

Apptainer provides a familiar HPC artifact (`.sif`) and does not require users to run a privileged Docker daemon.

Illustrative GPU launch:

```bash
srun apptainer exec \
  --nv \
  --cleanenv \
  --bind /shared/data:/data:ro \
  --bind /shared/checkpoints:/checkpoints \
  /shared/containers/training-by-digest.sif \
  python /workspace/train.py
```

`--nv` exposes NVIDIA devices and suitable host driver libraries. The host image must already contain a working driver.

## Image publication pipeline

Keep the Dockerfile/OCI image as the application source of truth:

```text
Dockerfile -> build OCI image -> push immutable digest to Artifact Registry
                                      |
                                      +-> convert/import to .sif
                                      |
                                      +-> convert/import to .sqsh
```

Prefer digest-derived filenames:

```text
/shared/containers/myapp/sha256-<digest>.sif
/shared/containers/myapp/sha256-<digest>.sqsh
```

Do not rely on mutable `latest` tags for production jobs.

## Storage and cold-start strategy

Directly pulling and unpacking a large image on every new autoscaled node adds substantial startup latency and registry load. A practical hierarchy is:

1. immutable artifact on shared high-throughput storage;
2. per-node staging to local SSD when absent;
3. lock around the copy/import so tasks do not duplicate work;
4. run from local SSD;
5. persist checkpoints and outputs to shared storage.

Node-local cache and local SSD must be treated as disposable, especially with Spot.

For very stable, large images, baking the artifact into the host VM image can reduce cold start, but couples application release cadence to VM image builds.

## GPU and high-performance networking

A container does not replace machine-specific host networking configuration. For A3/A4-class systems, validate the exact blueprint's requirements for:

- host libraries and sockets mounted into the container;
- network device names;
- NCCL environment variables;
- PMIx/MPI launch compatibility;
- GPUDirect TCPX/TCPXO or RDMA components;
- local SSD paths used for Enroot cache/data/runtime.

Do not copy mount/environment settings between accelerator families without validation.

## Spot behavior

The container runtime behaves the same on Standard and Spot nodes. Spot reclamation terminates the container and all job processes. Therefore:

- use Slurm requeue policy where appropriate;
- make startup idempotent;
- checkpoint frequently to shared/persistent storage;
- make the image immutable so a requeued job sees the same environment;
- never keep the only result/checkpoint in the container writable layer.

## Isolation caveat

Enroot/Pyxis and Apptainer are optimized for HPC usability and performance. They should not automatically be treated as a strong hostile multi-tenant boundary. Use explicit mounts, read-only roots where possible, least-privilege service accounts, and no Docker socket exposure.
