# Executive Summary

## Recommended design

```text
Developer workstation (non-root)
        |
        | SSH/IAP for terminal workflows
        | HTTPS for optional API/CI workflows
        v
In-cluster login/submit node
  - Slurm clients
  - sackd or MUNGE as configured
  - shared filesystems
  - optional tmux
        |
        | sbatch / srun / squeue / scancel
        v
Slurm controller
        |
        | ResumeProgram asks Google Compute Engine to create VMs
        v
Autoscaled Standard and/or Spot compute nodes
  - host Slurm daemon
  - host drivers/network/filesystem clients
  - Apptainer or Enroot/Pyxis
        |
        v
Per-job immutable workload container
```

## Key conclusions

1. **Cluster Toolkit can scale Slurm compute from zero.** Slurm predefines logical `State=CLOUD` nodes. When a job requires one, `ResumeProgram` invokes Cluster Toolkit/Slurm-GCP scripts that create Compute Engine VMs from nodeset instance templates. Normal scale-down deletes dynamic VMs.

2. **Spot is supported at the nodeset/template level.** A Spot nodeset uses the same Slurm autoscaling lifecycle but its instance template requests the `SPOT` provisioning model. A running job is still interruptible and must rely on requeue plus checkpoint/restart.

3. **Use containers per job, not as the VM image field.** The VM image remains a Compute Engine OS image containing Slurm, drivers, network stack, storage clients, and the container runtime. The application environment is an Apptainer `.sif` or Enroot/Pyxis-compatible OCI/`.sqsh` image.

4. **A non-root developer does not need controller SSH.** Use a dedicated login node. Batch commands can be executed through one-shot SSH/IAP calls. Interactive debugging can use `ssh -tt login 'srun ... --pty ...'`, so the terminal is local while `srun` remains inside the cluster.

5. **A user-space `srun` binary on an unmanaged dev box is not enough.** It also needs Slurm authentication, compatible config/version, correct Unix identity, cluster-visible paths, controller reachability, and inbound callbacks from compute nodes. Meeting those requirements effectively turns the dev box into an administrator-managed submit/login host.

6. **JWT/REST is useful for batch automation, not a full interactive replacement.** An HTTPS gateway backed by `slurmrestd` can serve CI, IDEs, and local CLIs, but interactive shells should still run `srun` from a trusted in-cluster host.

## Container runtime choice

- Choose **Enroot + Pyxis** for GPU-heavy, distributed AI workloads, especially when using NVIDIA/Google accelerator blueprints that already integrate the required host stack.
- Choose **Apptainer** for general HPC, CPU workloads, and a conventional portable `.sif` workflow.

## Production priorities

- Pin the Cluster Toolkit revision.
- Keep the controller and authentication keys private.
- Keep login nodes small but available.
- Store immutable container artifacts on shared storage or in a registry plus a controlled staging path.
- Stage large images onto local SSD where beneficial, but never store the only checkpoint/output there.
- Define Spot partitions, requeue policy, checkpoint conventions, and user expectations explicitly.
