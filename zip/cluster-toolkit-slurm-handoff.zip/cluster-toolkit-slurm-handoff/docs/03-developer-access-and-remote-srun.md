# Developer Access and Remote `srun`

## Direct answer

A developer with a non-sudo account does **not** need to SSH to the Slurm controller/head node. The intended entry point is a dedicated Cluster Toolkit Slurm **login node**.

A developer can avoid an interactive login shell for batch operations. For interactive debugging, the recommended pattern is to execute `srun` on the login node through SSH/IAP while forwarding the terminal.

## Why a local user-space `srun` is usually insufficient

Installing a Slurm binary under `$HOME` solves only the executable problem. A working client host also needs:

1. **Authentication** — native Slurm authentication via `sackd`, MUNGE, or an allowed alternate mechanism. Long-lived cluster signing/authentication keys should not be handed to unmanaged developer machines.
2. **Compatible configuration and version** — access to `slurm.conf` or configless configuration and compatible client/plugin versions.
3. **Unix identity** — the username and typically UID/GID must resolve consistently in the cluster.
4. **Network reachability** — ordinary clients contact `slurmctld`; interactive `srun` additionally receives connections from `slurmstepd` on compute nodes.
5. **Filesystem/path visibility** — working directory, program, container image, data, and outputs must exist on cluster-visible storage.

Interactive `srun` is the decisive networking issue. The machine running `srun` opens job-I/O sockets, and compute nodes connect back to it. A laptop behind NAT or a simple single-port SSH tunnel normally cannot receive those callbacks.

If administrators install auth helpers, keys, Slurm packages, shared mounts, identity integration, stable routing, and firewall rules on the dev box, it has effectively become another managed submit/login host.

## Batch submission without an interactive shell

```bash
ssh slurm-login \
  'sbatch --parsable --chdir=/shared/work/my-project' \
  < train.sbatch
```

Related commands:

```bash
ssh slurm-login 'squeue -u "$USER"'
ssh slurm-login 'sacct -j 123456'
ssh slurm-login 'scancel 123456'
ssh slurm-login 'tail -f /shared/work/my-project/logs/train-123456.out'
```

The local script is streamed to remote `sbatch`, but application code and data are not automatically uploaded. Put those on shared storage, synchronize them separately, or fetch immutable content at job startup.

## Interactive debugging

```bash
ssh -tt slurm-login \
  'srun \
      --partition=debug \
      --nodes=1 \
      --ntasks=1 \
      --cpus-per-task=8 \
      --mem=32G \
      --time=01:00:00 \
      --pty bash -l'
```

The terminal is on the developer machine, the `srun` process is on the login node, and the shell is on the allocated compute node.

### Pyxis example

```bash
ssh -tt slurm-login \
  'srun \
      --partition=debug \
      --nodes=1 \
      --gpus=1 \
      --time=01:00:00 \
      --container-image=/shared/containers/dev.sqsh \
      --container-mounts=/shared/work:/work,/shared/data:/data \
      --pty bash -l'
```

### Apptainer example

```bash
ssh -tt slurm-login \
  'srun \
      --partition=debug \
      --nodes=1 \
      --gpus=1 \
      --time=01:00:00 \
      --pty \
      apptainer exec --nv \
        --bind /shared/work:/work \
        --bind /shared/data:/data \
        /shared/containers/dev.sif \
        bash -l'
```

## Local-feeling wrapper

A shell function or script can quote arguments and invoke remote `srun`. See `examples/cluster_srun.sh`.

This preserves the correct trust and networking boundary while providing a familiar command-line experience.

## Handling disconnects

Use `tmux` or another persistent terminal on the login node for long interactive sessions:

```bash
ssh -tt slurm-login 'tmux new-session -A -s slurm-debug'
```

Then run `srun --pty` inside it. Source, logs, and checkpoints should still be on shared storage.

## JWT and local clients

JWT can be useful for noninteractive client-to-controller/API operations if the Slurm configuration allows it and the dev box receives a short-lived, user-scoped token. It does not remove the interactive `srun` callback and authentication requirements, and should not be considered the normal solution for local interactive steps.

Never distribute the JWT signing key. Put token issuance behind a trusted service and company identity.

## REST/API alternative

For CI, IDE integrations, and users without SSH access:

```text
local CLI/CI -> HTTPS gateway -> slurmrestd -> slurmctld
```

The gateway can expose submit, status, cancel, and log workflows. Interactive terminals should still traverse SSH/IAP or another in-cluster terminal gateway and execute `srun` there.
