# Open Questions and Validation Checklist

These items should be resolved before turning the design into production code.

## Version and module selection

- Which Cluster Toolkit release or commit SHA will be pinned?
- Are the `schedmd-slurm-gcp-v6-*` community module paths still correct at that revision?
- What Slurm version and plugin ABI are in the chosen image?
- Is the selected module family production-supported for the target environment?

## Workload profile

- CPU-only, GPU, TPU, or mixed?
- Which exact machine families and accelerator variants?
- Single-node or multi-node MPI/PMIx?
- Required network topology and placement policy?
- Typical container size and node startup SLO?

## Runtime choice

- Apptainer or Enroot/Pyxis?
- Does the base image already include the runtime and required SPANK plugin?
- If not, what custom-image build process will install and test it?
- How are OCI images converted to `.sif`/`.sqsh`, signed, scanned, and promoted?

## Storage

- Where do source code, datasets, container artifacts, logs, outputs, and checkpoints live?
- Is shared storage mounted identically on login and compute nodes?
- Is throughput adequate for many nodes staging a large image simultaneously?
- Is local SSD available and initialized by the selected blueprint?

## Authentication and identity

- Is the cluster using `auth/slurm`/`sackd`, MUNGE, JWT alternate auth, or a combination?
- How are Slurm keys rotated?
- How are users and UID/GID values synchronized?
- Does OS Login integrate cleanly with the filesystem identity model?
- Who may receive short-lived JWTs, and how are they issued/revoked?

## Developer connectivity

- SSH directly to a private login node, or IAP?
- Is a bastion required?
- Will developers use local wrappers, a CLI, an IDE extension, or all three?
- Is `tmux` permitted and installed for persistent interactive sessions?
- Is `SrunPortRange` constrained, and are compute-to-login firewall rules present?

## API path

- Is `slurmrestd` enabled in the exact generated configuration?
- Where does it listen, and is TLS terminated directly or at a gateway?
- Which Slurm OpenAPI version is exposed?
- How will company identity map to a Slurm user?
- How will logs and cluster-visible artifacts be uploaded/retrieved?

## Spot policy

- Separate Spot and Standard partitions?
- `STOP` or `DELETE` termination action?
- Slurm job requeue defaults and retry limits?
- Application checkpoint interval and recovery command?
- Standard fallback workflow for urgent/non-checkpointable jobs?
- Placement policy trade-off between topology and capacity availability?

## Operational tests

- Measure cold-start time from queued job to running container.
- Verify behavior when image staging fails.
- Verify behavior when a VM never registers before `ResumeTimeout`.
- Inject Spot preemption and observe job/node/accounting state.
- Verify dynamic VM deletion after idle/job completion.
- Verify no cluster auth secret is present on the developer workstation.
- Verify controller access is unnecessary for normal users.
