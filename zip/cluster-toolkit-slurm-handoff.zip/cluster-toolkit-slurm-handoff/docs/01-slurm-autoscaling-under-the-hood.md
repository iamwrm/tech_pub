# Slurm Autoscaling Under the Hood

## Two independent meanings of "on demand"

| Concern | Setting/behavior |
|---|---|
| Create a VM only when Slurm schedules work | Dynamic Slurm cloud nodes; typically `node_count_static: 0` and `node_count_dynamic_max > 0` |
| Purchase/provisioning class | Standard VM when Spot is disabled; Spot VM when `enable_spot_vm: true` |

A cluster can therefore have autoscaling Standard nodes, autoscaling Spot nodes, or separate partitions/nodesets for both.

## Deployment-time work

Cluster Toolkit/Terraform creates the stable infrastructure and definitions:

- network, firewall, service accounts, buckets, filesystems;
- controller and login nodes;
- one Compute Engine instance template per compute nodeset;
- generated Slurm node/partition configuration;
- controller-side Slurm-GCP scripts.

It does not normally run Terraform for every job. Runtime scaling is driven by Slurm and controller-side scripts.

## Logical cloud nodes

The generated Slurm configuration predeclares node-name ranges with `State=CLOUD`. A logical Slurm node can exist in scheduler state even when no Compute Engine VM exists for that name.

The generated configuration associates power-save hooks with scripts similar to:

```text
ResumeProgram=.../resume_wrapper.sh
ResumeFailProgram=.../suspend_wrapper.sh
SuspendProgram=.../suspend_wrapper.sh
```

## Scale-up sequence

```text
1. A job becomes schedulable.
2. slurmctld selects one or more logical State=CLOUD node names.
3. Slurm invokes ResumeProgram with the selected names.
4. resume.py reads the resume request/job metadata.
5. It groups nodes by nodeset, job, zone/placement requirements.
6. It calls Compute Engine Bulk Insert using the nodeset instance template.
7. Each VM is created with its Slurm node name.
8. The VM startup script downloads cluster configuration/scripts from GCS.
9. setup.py configures mounts, auth helpers, and slurmd.
10. slurmd starts in configless mode and registers with slurmctld.
11. Slurm launches the allocated job step.
```

The normal path creates fresh VMs. It is not generally a pool of permanently stopped instances waiting for `start` calls.

## Bulk Insert behavior

The resume code creates a request whose per-instance properties contain the exact Slurm node names. Depending on allowed locations, it can use zonal or regional Bulk Insert. Regional placement can improve the chance of finding capacity across configured zones.

Placement-group/all-or-nothing settings matter for large allocations. Tightly placed requests can fail as a whole when capacity is fragmented, which is especially relevant for Spot.

## VM bootstrap

The compute instance template contains metadata identifying the VM as a Slurm compute node and pointing to the cluster configuration bucket. On boot, the startup/setup path typically:

- downloads the Slurm-GCP scripts/configuration archive;
- configures shared storage and NSS/identity integration;
- starts MUNGE or native Slurm auth helpers as selected;
- starts `slurmd` and obtains config from the controller;
- runs any custom setup required by the image/blueprint.

Cold-start time includes Compute Engine provisioning, OS boot, startup scripts, mounts, runtime initialization, and Slurm registration. `ResumeTimeout` must cover the realistic worst case.

## Scale-down sequence

For ordinary dynamic nodes, the suspend script calls the Compute Engine instances delete API. In other words:

```text
idle dynamic node -> SuspendProgram -> delete VM
```

Static node ranges can be excluded from suspend. Some configurations can power down exclusive nodes immediately after the job rather than waiting for the generic idle timeout.

## Spot nodes

At template construction time, enabling Spot changes the Compute Engine scheduling/provisioning model to `SPOT` and disables automatic restart as required for Spot/preemptible behavior. The Slurm scale-up path itself is otherwise the same.

Illustrative nodeset settings:

```yaml
settings:
  node_count_static: 0
  node_count_dynamic_max: 100
  enable_spot_vm: true
  spot_instance_config:
    termination_action: STOP
```

Validate these field names against the pinned Cluster Toolkit revision.

## Spot preemption

### STOP termination action

A preempted VM may remain as an existing instance in `TERMINATED` state. The controller reconciliation logic can recognize a terminated preemptible/Spot instance, mark the Slurm node down, and attempt to start that instance again.

This is an exceptional recovery path. It does not restore the interrupted process state or guarantee capacity on restart.

### DELETE termination action

The instance disappears. Later, a Slurm resume can create a fresh replacement VM from the nodeset template.

### Application consequence

In both cases:

```text
Spot VM reclaimed -> container and job processes die -> Slurm detects failure -> job may be requeued -> application resumes only from persisted checkpoint
```

Use separate Spot partitions/nodesets and communicate the interruption contract clearly. Keep non-checkpointable work on Standard capacity.
