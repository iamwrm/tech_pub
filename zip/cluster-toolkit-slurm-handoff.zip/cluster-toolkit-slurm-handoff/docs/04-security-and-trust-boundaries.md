# Security and Trust Boundaries

## Preferred boundary

```text
Unmanaged developer workstation
  - no Slurm cluster signing key
  - no MUNGE key
  - no direct controller SSH
  - company SSH/IAP or HTTPS identity only
        |
        v
Managed login/API tier
  - Slurm client binaries
  - cluster auth helper/key access
  - private VPC routing
  - shared filesystems
        |
        v
Private controller and autoscaled compute nodes
```

## Slurm authentication

The exact deployment can use native Slurm authentication (`auth/slurm` with `sackd`), MUNGE, and/or JWT as an alternate client mechanism. Validate the generated configuration for the pinned release.

The security rule is stable regardless of mechanism: cluster signing/authentication keys belong on administrator-managed hosts. An unmanaged workstation's root administrator could extract such a key, so distributing it expands the cluster trust boundary substantially.

## Network requirements

- Common client commands need controller reachability.
- Interactive `srun` also needs compute-to-submit-host return connectivity over the configured job-I/O port range.
- A laptop behind NAT, IAP TCP forwarding, or a single SSH local forward normally does not satisfy this.
- Keep the controller private; expose a login tier or a narrowly scoped API tier instead.

Create an explicit firewall matrix covering:

- developer to login node through SSH/IAP;
- login node to controller;
- compute node to controller;
- compute node to login node for interactive job I/O;
- nodes to storage, Artifact Registry/GCS, DNS, identity, and monitoring services;
- optional API gateway to `slurmrestd`.

## User identity

A submitted username must map correctly across login and compute nodes. Decide whether identity is provided by OS Login, LDAP/SSSD, local synchronized accounts, or another supported strategy. Validate UID/GID consistency for shared filesystems.

## Container controls

- Prefer read-only container roots.
- Do not automatically mount the user's entire home directory when unnecessary.
- Use explicit read-only/read-write bind mounts.
- Do not expose `/var/run/docker.sock`.
- Use least-privilege VM service accounts and IAM scopes.
- Separate trusted and untrusted workloads when container isolation is not a sufficient hostile-tenant boundary.
- Keep secrets out of images, batch scripts, and Slurm environment dumps.

## Artifact integrity

- Reference OCI images by digest.
- Name `.sif`/`.sqsh` artifacts by digest or immutable release ID.
- Record the source digest and conversion tool/version.
- Verify checksum before staging to local SSD.
- Control who can publish to the production artifact namespace.

## Spot risk controls

- Make Spot partitions explicit.
- Require or strongly encourage checkpointing.
- Persist outputs outside the VM/container/local SSD.
- Define requeue limits to avoid endless retry loops during capacity shortages.
- Consider Standard fallback as a separate policy/workflow; do not assume the nodeset automatically changes from Spot to Standard.
