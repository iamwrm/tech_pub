# Instructions for Codex

## Objective

Turn this handoff into a reproducible design and, if requested, an implementation for a Google Cloud Cluster Toolkit Slurm environment with:

- compute nodes created only when Slurm needs them;
- optional Spot nodes;
- per-job OCI-derived container environments;
- non-root developer workstations;
- secure batch submission and interactive debugging;
- no routine user access to the Slurm controller.

## Canonical architecture

Use an **in-cluster login/submit node** as the Slurm client execution environment. A developer may invoke it through SSH/IAP wrappers so the terminal feels local, but the real `sbatch`, `squeue`, and especially `srun` processes execute on the trusted, routable login node.

Use the Compute Engine image for host responsibilities:

- Slurm daemon/client and plugins;
- host kernel and drivers;
- GPU, RDMA, GPUDirect, and filesystem clients;
- Apptainer or Enroot/Pyxis runtime;
- authentication agent such as `sackd` or MUNGE where applicable.

Use the workload container for:

- application code;
- Python/Conda or language runtime;
- framework and user-space libraries;
- reproducible application dependencies.

Do **not** place an OCI registry URI in Cluster Toolkit's `instance_image`; that field selects a Compute Engine OS image.

## Required validation before implementation

1. Pin a Cluster Toolkit release or commit SHA.
2. Confirm the selected Slurm v6 modules, field names, and generated Slurm configuration at that revision.
3. Confirm the cluster authentication mode: native `auth/slurm`/`sackd`, MUNGE, JWT for client-to-controller calls, or a combination.
4. Confirm whether `slurmrestd` is enabled, bound, authenticated, and exposed in the selected blueprint.
5. Confirm user identity strategy and UID/GID consistency across login and compute nodes.
6. Confirm network paths, firewall rules, IAP/SSH access, and private DNS.
7. Choose Apptainer or Enroot/Pyxis based on workload and machine family.
8. Decide where immutable container artifacts live and how they are staged/cached.
9. Define Spot requeue/checkpoint behavior and the desired Spot termination action.
10. Validate GPU/RDMA/NCCL mounts and environment against the exact accelerator blueprint.

## Design constraints

- Keep the Slurm controller private and out of the normal developer workflow.
- Do not distribute Slurm signing/authentication keys to unmanaged developer machines.
- Do not claim a user-installed `srun` binary is sufficient. Interactive `srun` needs authentication, identity, configuration, filesystem visibility, and bidirectional connectivity from compute nodes to the host running `srun`.
- JWT can enable selected noninteractive Slurm client/API calls, but should not be treated as a complete interactive `srun` solution.
- Treat Spot interruption as job/process loss. Recovery requires Slurm requeue policy plus application checkpoint/restart.
- Treat node-local caches, container writable layers, and local SSD as disposable.
- Use immutable container digests or versioned `.sif`/`.sqsh` artifacts rather than mutable tags.

## Recommended developer interfaces

### Interactive

```text
local terminal -> SSH/IAP -> login node -> srun --pty -> autoscaled compute VM -> container shell
```

### Batch

Use either:

```text
local CLI -> SSH remote sbatch -> slurmctld
```

or:

```text
local CLI/CI -> authenticated HTTPS gateway -> slurmrestd -> slurmctld
```

The gateway approach should issue or broker short-lived, user-scoped credentials. Never put the cluster JWT signing key on a workstation.

## Suggested deliverables

When implementing, produce:

- a pinned blueprint and any custom-image build files;
- a threat model and firewall matrix;
- login-node bootstrap and runtime validation tests;
- batch and interactive client wrappers;
- example Apptainer or Pyxis jobs;
- a container artifact publication/staging workflow;
- a Spot interruption/requeue integration test;
- operator runbooks for auth-key rotation, image upgrades, and failed node cleanup.

## Acceptance tests

At minimum, demonstrate:

1. `sbatch` submitted from a non-root dev box through the supported entry point.
2. `squeue`, `sacct`, `scancel`, and log retrieval from that dev box.
3. `srun --pty` launched from the dev box while the real `srun` process runs on the login node.
4. Scale from zero: a logical Slurm cloud node causes a VM to be created and registered.
5. Container execution by immutable artifact/digest.
6. GPU visibility inside the container, when applicable.
7. Shared checkpoint/output persistence after the compute VM is deleted.
8. Spot preemption causing expected job failure/requeue behavior.
9. No Slurm cluster secret present on the unmanaged dev box.
10. Controller SSH is not required for ordinary users.
