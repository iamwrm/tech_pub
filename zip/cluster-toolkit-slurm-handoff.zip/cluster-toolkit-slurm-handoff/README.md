# Cluster Toolkit + Slurm: Codex Handoff Pack

Export date: **2026-07-28**

This archive captures the visible conversation and distills it into implementation-oriented notes for an engineer or coding agent. The subject is Google Cloud Cluster Toolkit, Slurm elastic compute, Spot VMs, workload containers, and developer access from a non-root workstation.

## Read order

1. [`AGENTS.md`](AGENTS.md) — instructions, assumptions, and acceptance criteria for Codex.
2. [`docs/00-executive-summary.md`](docs/00-executive-summary.md) — the design in one page.
3. [`docs/01-slurm-autoscaling-under-the-hood.md`](docs/01-slurm-autoscaling-under-the-hood.md) — VM creation, registration, suspend, and Spot behavior.
4. [`docs/02-container-runtime-design.md`](docs/02-container-runtime-design.md) — Apptainer versus Enroot/Pyxis, image lifecycle, GPU concerns, and staging.
5. [`docs/03-developer-access-and-remote-srun.md`](docs/03-developer-access-and-remote-srun.md) — why a user-space local `srun` is usually insufficient and how to provide a local-feeling workflow.
6. [`docs/04-security-and-trust-boundaries.md`](docs/04-security-and-trust-boundaries.md) — authentication, networking, identities, credentials, and multi-tenant concerns.
7. [`docs/05-open-questions-and-validation.md`](docs/05-open-questions-and-validation.md) — decisions and facts that must be verified against the exact deployment/version.
8. [`conversation.md`](conversation.md) — visible transcript.
9. [`references/links.md`](references/links.md) — source inventory from the conversation.

## Included examples

- `examples/slurm-apptainer-spot-blueprint.yaml` — illustrative Cluster Toolkit blueprint fragment.
- `examples/apptainer-job.sbatch` — CPU/GPU-capable Apptainer batch pattern.
- `examples/pyxis-job.sbatch` — Pyxis/Enroot batch pattern.
- `examples/cluster_srun.sh` — local shell wrapper that executes `srun` on an in-cluster login node.
- `examples/cluster_submit.sh` — submit a local script through remote `sbatch` without an interactive SSH shell.
- `examples/slurmrestd-client-outline.md` — batch/API alternative for CI and IDE integration.

## Important scope note

This is a conversation export and design handoff, not a substitute for pinning and reviewing the exact Cluster Toolkit and Slurm versions in production. Repository paths and defaults can change. The first implementation task should be to select a Cluster Toolkit commit/release and validate each referenced module and configuration key against that revision.

The archive contains only visible conversation content and derived design notes; it does not contain private reasoning or hidden system material.
