# Suggested Prompt for Codex

Read `AGENTS.md`, then all files under `docs/`, `examples/`, `diagrams/`, and `references/`. Treat `conversation.md` as the original context.

Your task is to turn the design into a production-ready proposal or implementation for our environment. Do not assume GitHub `main` is stable: first pin a Google Cloud Cluster Toolkit release/commit and verify every module path, variable, generated Slurm setting, and authentication claim against that revision and the corresponding Slurm documentation.

Priorities:

1. Scale-to-zero Slurm compute nodes created by Cluster Toolkit on job demand.
2. Separate Standard and Spot nodesets/partitions, with explicit interruption, requeue, and checkpoint behavior.
3. Per-job container runtime using either Apptainer or Enroot/Pyxis; do not confuse workload OCI images with Compute Engine `instance_image`.
4. A non-root developer workflow that never requires routine controller SSH.
5. Interactive debugging through `SSH/IAP -> login node -> srun --pty -> compute container`.
6. Batch/CI through remote `sbatch` and optionally a secure `slurmrestd` gateway.
7. No Slurm authentication/signing key on unmanaged developer workstations.
8. Immutable container artifacts, shared persistent checkpoints, and disposable node-local caches.

Start by producing:

- a list of facts validated at the pinned revisions, with exact file/line references;
- a proposed architecture and trust-boundary diagram;
- a decision between Apptainer and Enroot/Pyxis based on the supplied workload assumptions or clearly stated assumptions;
- a concrete Cluster Toolkit blueprint/custom-image plan;
- firewall and identity requirements;
- client wrapper/API design;
- end-to-end acceptance and failure-injection tests;
- risks, unresolved decisions, and rollout sequence.

Do not silently invent missing organization-specific details. Isolate them as configuration inputs or open decisions while still producing a complete best-effort design.
